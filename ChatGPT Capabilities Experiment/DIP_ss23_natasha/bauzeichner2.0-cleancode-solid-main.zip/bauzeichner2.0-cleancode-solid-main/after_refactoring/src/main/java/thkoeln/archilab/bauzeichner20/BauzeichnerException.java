package thkoeln.archilab.bauzeichner20;

public class BauzeichnerException extends RuntimeException {

    public BauzeichnerException(String message) {
        super(message);
    }
}
