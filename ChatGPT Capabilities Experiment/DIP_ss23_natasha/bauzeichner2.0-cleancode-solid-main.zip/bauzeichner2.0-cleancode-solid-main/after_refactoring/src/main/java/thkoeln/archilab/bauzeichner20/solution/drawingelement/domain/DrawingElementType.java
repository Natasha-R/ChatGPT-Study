package thkoeln.archilab.bauzeichner20.solution.drawingelement.domain;

public enum DrawingElementType {
    DOOR,
    WINDOW
}
