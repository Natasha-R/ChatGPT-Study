package thkoeln.archilab.bauzeichner20.solution.canvas.domain;

public enum DirectionType {
    LEFT,
    RIGHT,
    TOP,
    BOTTOM
}
