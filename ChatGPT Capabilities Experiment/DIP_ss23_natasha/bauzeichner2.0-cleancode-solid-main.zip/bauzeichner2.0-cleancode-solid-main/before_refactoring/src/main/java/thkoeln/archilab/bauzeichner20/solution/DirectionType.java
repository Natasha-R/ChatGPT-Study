package thkoeln.archilab.bauzeichner20.solution;

public enum DirectionType {
    LEFT,
    RIGHT,
    TOP,
    BOTTOM
}
