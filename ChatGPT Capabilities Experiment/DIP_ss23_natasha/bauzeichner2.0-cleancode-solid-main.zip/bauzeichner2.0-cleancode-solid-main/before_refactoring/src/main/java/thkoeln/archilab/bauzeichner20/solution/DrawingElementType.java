package thkoeln.archilab.bauzeichner20.solution;

public enum DrawingElementType {
    DOOR,
    WINDOW
}
